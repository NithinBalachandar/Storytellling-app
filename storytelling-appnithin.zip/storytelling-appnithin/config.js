export const firebaseConfig = {
  apiKey: "AIzaSyDPC-mWe4RuzQucWyqHoblDYQ1RCwzkwEw",
  authDomain: "story-telling-app-a3701.firebaseapp.com",
  databaseURL: "https://story-telling-app-a3701-default-rtdb.firebaseio.com",
  projectId: "story-telling-app-a3701",
  storageBucket: "story-telling-app-a3701.appspot.com",
  messagingSenderId: "696427002963",
  appId: "1:696427002963:web:a253302e4b9a97b3fd5aa6",
  measurementId: "G-2K61B6FPGL"
};